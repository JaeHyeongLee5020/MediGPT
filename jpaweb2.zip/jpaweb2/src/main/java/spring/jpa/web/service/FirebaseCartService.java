package spring.jpa.web.service;

import com.google.firebase.database.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.CountDownLatch;

@Service
@RequiredArgsConstructor
public class FirebaseCartService {

    private final DatabaseReference db = FirebaseDatabase.getInstance().getReference();

    // 장바구니에 상품 추가
    public void addToCart(String username, String name, int price) {
        DatabaseReference userCartRef = db.child("carts").child(username).child(name);

        userCartRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                int quantity = 1;
                if (snapshot.exists()) {
                    Long existingQty = snapshot.child("quantity").getValue(Long.class);
                    if (existingQty != null) {
                        quantity += existingQty;
                    }
                }

                Map<String, Object> itemData = new HashMap<>();
                itemData.put("name", name);
                itemData.put("price", price);
                itemData.put("quantity", quantity);

                userCartRef.setValueAsync(itemData);
            }

            @Override
            public void onCancelled(DatabaseError error) {
                System.err.println("Firebase error: " + error.getMessage());
            }
        });
    }

    // 사용자 장바구니 조회
    public List<Map<String, Object>> getCartItems(String username) {
        List<Map<String, Object>> cartItems = new ArrayList<>();
        CountDownLatch latch = new CountDownLatch(1);

        db.child("carts").child(username).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                for (DataSnapshot itemSnapshot : snapshot.getChildren()) {
                    Map<String, Object> item = new HashMap<>();
                    item.put("name", itemSnapshot.child("name").getValue());
                    item.put("price", itemSnapshot.child("price").getValue());
                    item.put("quantity", itemSnapshot.child("quantity").getValue());
                    cartItems.add(item);
                }
                latch.countDown();
            }

            @Override
            public void onCancelled(DatabaseError error) {
                System.err.println("Firebase read error: " + error.getMessage());
                latch.countDown();
            }
        });

        try {
            latch.await(); // Firebase 비동기 대기
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        return cartItems;
    }
    
    public void updateCartItem(String username, String name, String action) {
        DatabaseReference itemRef = db.child("carts").child(username).child(name);

        itemRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                if (!snapshot.exists()) return;

                Long currentQty = snapshot.child("quantity").getValue(Long.class);
                int quantity = currentQty != null ? currentQty.intValue() : 1;

                if ("increase".equals(action)) {
                    quantity += 1;
                } else if ("decrease".equals(action) && quantity > 1) {
                    quantity -= 1;
                }

                snapshot.getRef().child("quantity").setValueAsync(quantity);
            }

            @Override
            public void onCancelled(DatabaseError error) {
                System.err.println("Firebase update error: " + error.getMessage());
            }
        });
    }

    public void removeFromCart(String username, String name) {
        db.child("carts").child(username).child(name).removeValueAsync();
    }

    public void clearCart(String username) {
        db.child("carts").child(username).removeValueAsync();
    }

}
