package spring.jpa.web.controller;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import spring.jpa.web.service.FirebaseCartService;
import spring.jpa.web.service.FirebaseProductsService;
import spring.jpa.web.service.FirebaseUserService;

@Controller
@RequiredArgsConstructor
public class ShopController {

    private final FirebaseProductsService firebaseProductsService;
    private final FirebaseCartService firebaseCartService;
    private final FirebaseUserService firebaseUserService;

    @GetMapping("/shop")
    public String showShopPage(@RequestParam(name = "page", defaultValue = "1") double rawPage,
                               @RequestParam(name = "query", required = false) String query,
                               @RequestParam(name = "sort", required = false) String sort,
                               Model model,
                               HttpSession session) {

        int page = (int) Math.floor(rawPage); // 핵심: 소수점 제거
        page = Math.max(page, 1);
        session.setMaxInactiveInterval(1800);

        List<Map<String, Object>> allProducts = (query != null && !query.trim().isEmpty())
                ? firebaseProductsService.searchProducts(query.trim())
                : firebaseProductsService.getAllProducts();

        if (sort != null) {
            switch (sort) {
                case "priceAsc" -> allProducts.sort((a, b) ->
                        Integer.compare(Integer.parseInt(a.get("price").toString()),
                                        Integer.parseInt(b.get("price").toString())));
                case "priceDesc" -> allProducts.sort((a, b) ->
                        Integer.compare(Integer.parseInt(b.get("price").toString()),
                                        Integer.parseInt(a.get("price").toString())));
                case "nameAsc" -> allProducts.sort((a, b) ->
                        a.get("name").toString().compareToIgnoreCase(b.get("name").toString()));
            }
        }

        int perPage = 9;
        int totalPages = (int) Math.ceil((double) allProducts.size() / perPage);

        // 🧩 에러 방지용 보정
        page = Math.max(1, page);
        page = Math.min(page, totalPages == 0 ? 1 : totalPages);

        int start = (page - 1) * perPage;
        int end = Math.min(start + perPage, allProducts.size());

        List<Map<String, Object>> products = allProducts.subList(start, end);

        model.addAttribute("products", products);
        model.addAttribute("currentPage", page); // JSP용
        model.addAttribute("totalPages", totalPages);
        model.addAttribute("query", query);
        model.addAttribute("sort", sort);

        Object recommended = session.getAttribute("recommendedMeds");
        if (recommended instanceof List) {
            model.addAttribute("recommendedMeds", recommended);
        }

        String username = (String) session.getAttribute("username");
        if (username != null) {
            List<Map<String, Object>> cartItems = firebaseCartService.getCartItems(username);
            model.addAttribute("cartCount", cartItems.size());
        }

        addSessionTimer(session, model);
        return "shop";
    }

    @PostMapping("/cart/add")
    @ResponseBody
    public String addToCart(@RequestBody Map<String, Object> payload, HttpSession session) {
        String username = (String) session.getAttribute("username");
        if (username == null) return "로그인 필요";

        String name = (String) payload.get("name");
        int price = Integer.parseInt(payload.get("price").toString());

        firebaseCartService.addToCart(username, name, price);
        return "ok";
    }

    @GetMapping("/cart")
    public String showCartPage(HttpSession session, Model model) {
        String username = (String) session.getAttribute("username");
        if (username == null) return "redirect:/login";

        session.setMaxInactiveInterval(1800);

        List<Map<String, Object>> cartItems = firebaseCartService.getCartItems(username);
        int totalPrice = cartItems.stream()
            .mapToInt(item -> Integer.parseInt(item.get("price").toString()) *
                              Integer.parseInt(item.get("quantity").toString()))
            .sum();

        model.addAttribute("cartItems", cartItems);
        model.addAttribute("totalPrice", totalPrice);
        addSessionTimer(session, model);
        return "cart";
    }

    @PostMapping("/cart/update")
    @ResponseBody
    public String updateCart(@RequestParam("name") String name,
                             @RequestParam("action") String action,
                             HttpSession session) {
        String username = (String) session.getAttribute("username");
        if (username == null) return "로그인 필요";

        firebaseCartService.updateCartItem(username, name, action);
        return "ok";
    }

    @PostMapping("/cart/remove")
    @ResponseBody
    public String removeCart(@RequestParam("name") String name, HttpSession session) {
        String username = (String) session.getAttribute("username");
        if (username == null) return "로그인 필요";

        firebaseCartService.removeFromCart(username, name);
        return "ok";
    }

    @GetMapping("/checkout")
    public String showCheckoutPage(HttpSession session, Model model) {
        String username = (String) session.getAttribute("username");
        if (username == null) return "redirect:/login";

        session.setMaxInactiveInterval(1800);

        Map<String, Object> userInfo = firebaseUserService.getUserInfo(username);
        session.setAttribute("displayName", userInfo.getOrDefault("name", ""));
        session.setAttribute("email", userInfo.getOrDefault("email", ""));
        session.setAttribute("phone", userInfo.getOrDefault("phone", ""));
        session.setAttribute("address", userInfo.getOrDefault("address", ""));

        List<Map<String, Object>> cartItems = firebaseCartService.getCartItems(username);
        int totalPrice = cartItems.stream()
            .mapToInt(item -> Integer.parseInt(item.get("price").toString()) *
                              Integer.parseInt(item.get("quantity").toString()))
            .sum();

        model.addAttribute("cartItems", cartItems);
        model.addAttribute("totalPrice", totalPrice);
        model.addAttribute("username", username);

        addSessionTimer(session, model);
        return "checkout";
    }

    @PostMapping("/payment/complete")
    public String completePayment(@RequestParam Map<String, String> params, HttpSession session) {
        String username = (String) session.getAttribute("username");
        if (username == null) return "redirect:/login";

        List<Map<String, Object>> cartItems = firebaseCartService.getCartItems(username);

        Map<String, Object> paymentData = new HashMap<>();
        paymentData.put("products", cartItems);
        paymentData.put("timestamp", LocalDateTime.now().toString());
        paymentData.put("total", params.get("totalPrice"));

        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));

        DatabaseReference paymentRef = FirebaseDatabase.getInstance()
            .getReference("paymentHistory")
            .child(username)
            .child(timestamp);

        paymentRef.setValueAsync(paymentData);
        firebaseCartService.clearCart(username);

        session.setAttribute("totalPrice", params.get("totalPrice"));
        session.setAttribute("purchasedItems", cartItems);
        
        return "redirect:/paymentSuccess";
    }

    @GetMapping("/paymentSuccess")
    public String showPaymentSuccessPage(HttpSession session, Model model) {
        model.addAttribute("message", "결제가 성공적으로 완료되었습니다.");

        Object price = session.getAttribute("totalPrice");
        model.addAttribute("totalPrice", price != null ? price : 0);
        session.removeAttribute("totalPrice");

        Object items = session.getAttribute("purchasedItems");
        model.addAttribute("purchasedItems", items);
        session.removeAttribute("purchasedItems");

        return "paymentSuccess";
    }

    private void addSessionTimer(HttpSession session, Model model) {
        try {
            int maxInactiveInterval = session.getMaxInactiveInterval();
            long lastAccessedTime = session.getLastAccessedTime();
            long currentTime = System.currentTimeMillis();
            int remainingSeconds = (int) ((maxInactiveInterval * 1000L - (currentTime - lastAccessedTime)) / 1000);
            model.addAttribute("remainingSeconds", Math.max(remainingSeconds, 0));
        } catch (IllegalStateException e) {
            model.addAttribute("remainingSeconds", 0);
        }
    }

    @GetMapping("/products/autocomplete")
    @ResponseBody
    public List<String> autocomplete(@RequestParam("query") String query) {
        return firebaseProductsService.getAutocompleteSuggestions(query);
    }

    @GetMapping("/product/detail")
    public String showProductDetail(@RequestParam("id") String id, Model model, HttpSession session) {
        String username = (String) session.getAttribute("username");
        if (username == null) return "redirect:/login";

        session.setMaxInactiveInterval(1800);
        Map<String, Object> product = firebaseProductsService.getProductById(id);
        model.addAttribute("product", product);
        addSessionTimer(session, model);

        return "productDetail";
    }
    
    @GetMapping("/receipt")
    public String showReceipt(HttpSession session, Model model) {
        // JSP에서 생성했던 주문번호와 배송일
        String orderId = "ORD" + System.currentTimeMillis();
        String deliveryDate = LocalDate.now().plusDays(3).format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));

        model.addAttribute("orderId", orderId);
        model.addAttribute("deliveryDate", deliveryDate);
        model.addAttribute("purchasedItems", session.getAttribute("purchasedItems"));
        model.addAttribute("totalPrice", session.getAttribute("totalPrice"));

        return "receipt";
    }

    @GetMapping("/payment/receipt")
    public String showReceipt(@RequestParam String orderId, Model model, HttpSession session) {
        model.addAttribute("orderId", orderId);
        model.addAttribute("deliveryDate", LocalDate.now().plusDays(3));
        model.addAttribute("purchasedItems", session.getAttribute("purchasedItems"));
        model.addAttribute("totalPrice", session.getAttribute("totalPrice"));
        return "receipt"; // /WEB-INF/views/receipt.jsp
    }


}
