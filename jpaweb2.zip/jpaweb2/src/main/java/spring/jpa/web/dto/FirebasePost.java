package spring.jpa.web.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.util.Date;

@Data
public class FirebasePost {
    // Firebase Realtime-DB 의 key
    private String id;

    private String title;
    private String content;
    private String author;

    /**
     * JSON 에 저장된 ISO 8601 문자열을 Date 로 자동 역직렬화합니다.
     * ex) "2025-06-30T05:09:52.611+00:00"
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING,
                pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX",
                timezone = "UTC")
    private Date createdAt;

    @JsonFormat(shape = JsonFormat.Shape.STRING,
                pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX",
                timezone = "UTC")
    private Date updatedAt;

    private Long viewCount;
    private String imageUrl;
}