package spring.jpa.web.controller;

import com.google.cloud.storage.BlobInfo;
import com.google.cloud.storage.Storage;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;
import spring.jpa.web.dto.FirebasePost;

import java.io.IOException;
import java.util.*;
import java.util.Comparator;

@Slf4j
@Controller
@RequiredArgsConstructor
@RequestMapping("/posts")
public class PostController {

    private final RestTemplate restTemplate;
    private final Storage firebaseStorage;

    @Value("${firebase.database.url}")
    private String databaseUrl;

    @Value("${firebase.bucket.name}")
    private String bucketName;

    private boolean isNotLoggedIn(HttpSession session) {
        return session.getAttribute("displayName") == null;
    }

    // 1) 게시판 리스트 조회
    @GetMapping
    public String list(
            @RequestParam(name = "page", defaultValue = "1") int page,
            Model model,
            HttpSession session,
            HttpServletRequest request
    ) {
        if (isNotLoggedIn(session)) {
            return "redirect:/login";
        }
        addSessionTimeout(request, session);

        // Firebase에서 전체 글 읽어오기
        String url = databaseUrl + "/posts.json";
        ResponseEntity<Map<String, FirebasePost>> resp = restTemplate.exchange(
            url, HttpMethod.GET, null,
            new ParameterizedTypeReference<Map<String, FirebasePost>>() {}
        );
        Map<String, FirebasePost> body = resp.getBody();
        List<FirebasePost> posts = new ArrayList<>();
        if (body != null) {
            body.forEach((id, post) -> {
                post.setId(id);
                posts.add(post);
            });
        }
        // 최신순 정렬
        posts.sort(Comparator.comparing(FirebasePost::getCreatedAt).reversed());

        // 페이징
        int pageSize = 10;
        int totalPosts = posts.size();
        int totalPages = (int) Math.ceil((double) totalPosts / pageSize);
        page = Math.max(1, Math.min(page, totalPages));
        int from = (page - 1) * pageSize;
        int to = Math.min(from + pageSize, totalPosts);
        List<FirebasePost> paged = posts.subList(from, to);

        model.addAttribute("posts", paged);
        model.addAttribute("currentPage", page);
        model.addAttribute("totalPages", totalPages);
        return "posts/list";
    }

    // 2) 게시글 상세 조회
    @GetMapping("/{id}")
    public String detail(@PathVariable("id") String id,
                         Model model,
                         HttpSession session,
                         HttpServletRequest request) {
        if (isNotLoggedIn(session)) {
            return "redirect:/login";
        }
        addSessionTimeout(request, session);

        FirebasePost post = fetchPostById(id);
        if (post == null) {
            log.warn("No post with ID={}", id);
            return "redirect:/posts";
        }
        incrementViewCount(post);

        model.addAttribute("post", post);
        return "posts/detail";
    }

    // 3) 신규 글 작성 폼
    @GetMapping("/new")
    public String newForm(Model model,
                          HttpSession session,
                          HttpServletRequest request) {
        if (isNotLoggedIn(session)) {
            return "redirect:/login";
        }
        addSessionTimeout(request, session);

        model.addAttribute("post", new HashMap<String,Object>());
        return "posts/form";
    }

    // 4) 게시글 수정 폼
    @GetMapping("/edit")
    public String editForm(@RequestParam("id") String id,
                           Model model,
                           HttpSession session,
                           HttpServletRequest request) {
        if (isNotLoggedIn(session)) {
            return "redirect:/login";
        }
        addSessionTimeout(request, session);

        FirebasePost post = fetchPostById(id);
        if (post == null) {
            log.warn("No post to edit with ID={}", id);
            return "redirect:/posts";
        }
        model.addAttribute("post", post);
        return "posts/edit";
    }

    // 5) 글 저장 (신규 및 수정)
    @PostMapping
    public String save(@RequestParam Map<String, String> params,
                       @RequestParam(value = "imageFile", required = false) MultipartFile imageFile,
                       @RequestParam(value = "removeImage", required = false) boolean removeImage,
                       HttpSession session) throws IOException {
        if (isNotLoggedIn(session)) {
            return "redirect:/login";
        }
        String id = params.get("id");
        Map<String, Object> postData = buildPostData(params, imageFile, removeImage, session);

        HttpMethod method = (id == null || id.isEmpty()) ? HttpMethod.POST : HttpMethod.PATCH;
        String url = (id == null || id.isEmpty())
                     ? databaseUrl + "/posts.json"
                     : String.format("%s/posts/%s.json", databaseUrl, id);
        restTemplate.exchange(url, method, new HttpEntity<>(postData), Void.class);
        return "redirect:/posts";
    }

    // 6) 글 삭제
    @PostMapping("/delete")
    public String delete(@RequestParam("id") String id, HttpSession session) {
        if (isNotLoggedIn(session)) {
            return "redirect:/login";
        }
        String url = String.format("%s/posts/%s.json", databaseUrl, id);
        restTemplate.exchange(url, HttpMethod.DELETE, null, Void.class);
        return "redirect:/posts";
    }

    // --- 공통 헬퍼 메서드 ---
    private void addSessionTimeout(HttpServletRequest request, HttpSession session) {
        long now = System.currentTimeMillis();
        long lastAccessed = session.getLastAccessedTime();
        int maxInactive = session.getMaxInactiveInterval();
        int remaining = (int)((lastAccessed + maxInactive*1000L - now) / 1000L);
        if (remaining < 0) remaining = 0;
        request.setAttribute("remainingSeconds", remaining);
    }

    private FirebasePost fetchPostById(String id) {
        String url = String.format("%s/posts/%s.json", databaseUrl, id);
        ResponseEntity<FirebasePost> resp = restTemplate.exchange(
            url, HttpMethod.GET, null,
            new ParameterizedTypeReference<FirebasePost>() {}
        );
        FirebasePost post = resp.getBody();
        if (post != null) post.setId(id);
        return post;
    }

    private void incrementViewCount(FirebasePost post) {
        long vc = Optional.ofNullable(post.getViewCount()).orElse(0L) + 1;
        restTemplate.patchForObject(
            String.format("%s/posts/%s.json", databaseUrl, post.getId()),
            Collections.singletonMap("viewCount", vc),
            Void.class
        );
    }

    private Map<String, Object> buildPostData(Map<String, String> params,
                                              MultipartFile imageFile,
                                              boolean removeImage,
                                              HttpSession session) throws IOException {
        String id = params.get("id");
        String title = params.get("title");
        String content = params.get("content");
        String author = session.getAttribute("displayName").toString();
        Map<String, Object> data = new HashMap<>();
        data.put("title", title);
        data.put("content", content);
        data.put("author", author);
        Date now = new Date();
        data.put("updatedAt", now);
        if (id == null || id.isEmpty()) {
            data.put("createdAt", now);
            data.put("viewCount", 0);
        }
        // 이미지 처리
        if (removeImage) {
            data.put("imageUrl", null);
        } else if (imageFile != null && !imageFile.isEmpty()) {
            String objectName = "posts/" + System.currentTimeMillis() + "-" + imageFile.getOriginalFilename();
            BlobInfo blob = BlobInfo.newBuilder(bucketName, objectName)
                                   .setContentType(imageFile.getContentType())
                                   .build();
            firebaseStorage.create(blob, imageFile.getBytes());
            data.put("imageUrl",
                     String.format("https://storage.googleapis.com/%s/%s", bucketName, objectName));
        }
        return data;
    }
}