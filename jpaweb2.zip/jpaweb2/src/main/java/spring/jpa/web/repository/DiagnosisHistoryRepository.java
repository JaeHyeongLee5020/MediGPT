package spring.jpa.web.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import spring.jpa.web.entity.DiagnosisHistory;

import java.util.List;

public interface DiagnosisHistoryRepository extends JpaRepository<DiagnosisHistory, Long> {
    List<DiagnosisHistory> findByUserIdOrderByCreatedAtDesc(String userId);
}
