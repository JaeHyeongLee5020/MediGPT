package spring.jpa.web.controller;

import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import spring.jpa.web.entity.Product;
import spring.jpa.web.service.FirebaseProductsService;

@Controller
@RequiredArgsConstructor
public class ProductUploadController {

    private final FirebaseProductsService firebaseProductsService;

    // 👉 상품 등록 폼 페이지
    @GetMapping("/product/new")
    public String showProductForm(HttpSession session, Model model) {
        if (session == null || session.getAttribute("username") == null || session.getAttribute("displayName") == null) {
            return "redirect:/login";
        }

        String username = (String) session.getAttribute("username");
        if (!"admin".equals(username)) {
            return "redirect:/access-denied";
        }

        model.addAttribute("product", new Product());
        model.addAttribute("products", firebaseProductsService.getAllProducts()); // 상품 리스트

        // 💡 세션 시간 계산 로직도 추가 (header.jsp에서 remainingSeconds 사용)
        setSessionRemainingTime(session, model);

        return "productForm";
    }

    // 👉 상품 등록 처리
    @PostMapping("/product/save")
    public String saveProduct(@ModelAttribute Product product, HttpSession session) {
        if (session == null || session.getAttribute("username") == null) {
            return "redirect:/login";
        }

        String username = (String) session.getAttribute("username");
        if (!"admin".equals(username)) {
            return "redirect:/access-denied";
        }

        // Firebase에 저장
        firebaseProductsService.saveProductToFirebase(product);

        return "redirect:/shop";
    }

    // ✅ header.jsp에서 사용할 세션 타이머 남은 시간 계산
    private void setSessionRemainingTime(HttpSession session, Model model) {
        try {
            int maxInactiveInterval = session.getMaxInactiveInterval();
            long lastAccessedTime = session.getLastAccessedTime();
            long currentTime = System.currentTimeMillis();
            int remainingSeconds = (int) ((maxInactiveInterval * 1000L - (currentTime - lastAccessedTime)) / 1000);
            model.addAttribute("remainingSeconds", Math.max(remainingSeconds, 0));
        } catch (IllegalStateException e) {
            model.addAttribute("remainingSeconds", 0);
        }
    }
}
