package spring.jpa.web.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import spring.jpa.web.entity.Member;

@Repository
public interface MemberRepository extends JpaRepository<Member, Long> {
    /**
     * username 으로 회원을 조회할 때 사용됩니다.
     * 로그인 시에 반드시 이 메서드가 필요합니다.
     */
    Optional<Member> findByUsername(String username);
}