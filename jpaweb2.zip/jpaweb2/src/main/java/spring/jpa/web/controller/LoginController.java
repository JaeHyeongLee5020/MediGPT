package spring.jpa.web.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import spring.jpa.web.service.FirebaseUserService;

@Controller
@RequiredArgsConstructor
public class LoginController {

    private final FirebaseUserService firebaseUserService;

    @GetMapping("/login")
    public String showLoginForm() {
        return "login";
    }

    @PostMapping("/login")
    public String processLogin(@RequestParam("username") String username,
                               @RequestParam("password") String password,
                               HttpSession session,
                               Model model) {

        boolean success = firebaseUserService.authenticate(username, password);

        if (success) {
            session.setAttribute("username", username);
            String name = firebaseUserService.getNameByUsername(username);
            session.setAttribute("displayName", name);
            session.setAttribute("userId", username);

            // 관리자 여부 확인용 필드도 설정 가능
            if ("admin".equals(username)) {
                session.setAttribute("role", "ADMIN");
            } else {
                session.setAttribute("role", "USER");
            }

            session.setMaxInactiveInterval(1800);

            return "redirect:/main";
        } else {
            model.addAttribute("loginError", "아이디 또는 비밀번호가 올바르지 않습니다.");
            return "login";
        }
    }
}
