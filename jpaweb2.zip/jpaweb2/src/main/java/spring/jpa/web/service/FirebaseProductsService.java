package spring.jpa.web.service;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CountDownLatch;

import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import spring.jpa.web.entity.Product;

@Service
public class FirebaseProductsService {

    private final DatabaseReference db = FirebaseDatabase.getInstance().getReference();

    // 상품 등록
    public void saveProduct(String id, String name, String description, String imageUrl, int price, List<String> tags) {
        Map<String, Object> productMap = new HashMap<>();
        productMap.put("name", name);
        productMap.put("description", description);
        productMap.put("imageUrl", imageUrl);
        productMap.put("price", price);
        productMap.put("tags", tags);

        db.child("products").child(id).setValueAsync(productMap);
    }

    // 전체 상품 조회 (Map 타입)
    public List<Map<String, Object>> getAllProductsAsMap() {
        List<Map<String, Object>> productList = new ArrayList<>();
        CountDownLatch latch = new CountDownLatch(1);

        db.child("products").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                for (DataSnapshot child : snapshot.getChildren()) {
                    Map<String, Object> product = new HashMap<>();
                    for (DataSnapshot field : child.getChildren()) {
                        product.put(field.getKey(), field.getValue());
                    }
                    product.put("id", child.getKey());
                    productList.add(product);
                }
                latch.countDown();
            }

            @Override
            public void onCancelled(DatabaseError error) {
                latch.countDown();
            }
        });

        try {
            latch.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        return productList;
    }

    // 전체 상품 조회 (Map 타입)
    public List<Map<String, Object>> getAllProducts() {
        List<Map<String, Object>> productList = new ArrayList<>();
        CountDownLatch latch = new CountDownLatch(1);

        db.child("products").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                for (DataSnapshot child : snapshot.getChildren()) {
                    Map<String, Object> product = new HashMap<>();
                    for (DataSnapshot field : child.getChildren()) {
                        product.put(field.getKey(), field.getValue());
                    }
                    product.put("id", child.getKey());
                    productList.add(product);
                }
                latch.countDown();
            }

            @Override
            public void onCancelled(DatabaseError error) {
                latch.countDown();
            }
        });

        try {
            latch.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        return productList;
    }



    // 태그 검색
    public List<Map<String, Object>> findProductsByTag(String tag) {
        List<Map<String, Object>> result = new ArrayList<>();
        CountDownLatch latch = new CountDownLatch(1);

        db.child("products").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                for (DataSnapshot child : snapshot.getChildren()) {
                    List<String> tags = new ArrayList<>();
                    if (child.child("tags").getValue() != null) {
                        for (DataSnapshot tagSnap : child.child("tags").getChildren()) {
                            tags.add(tagSnap.getValue(String.class));
                        }
                        if (tags.contains(tag)) {
                            Map<String, Object> product = new HashMap<>();
                            for (DataSnapshot field : child.getChildren()) {
                                product.put(field.getKey(), field.getValue());
                            }
                            product.put("id", child.getKey());
                            result.add(product);
                        }
                    }
                }
                latch.countDown();
            }

            @Override
            public void onCancelled(DatabaseError error) {
                latch.countDown();
            }
        });

        try {
            latch.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        return result;
    }

    // 검색
    public List<Map<String, Object>> searchProducts(String keyword) {
        List<Map<String, Object>> result = new ArrayList<>();
        CountDownLatch latch = new CountDownLatch(1);

        db.child("products").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                for (DataSnapshot child : snapshot.getChildren()) {
                    String name = String.valueOf(child.child("name").getValue());
                    List<String> tags = new ArrayList<>();
                    if (child.child("tags").getValue() != null) {
                        for (DataSnapshot tagSnap : child.child("tags").getChildren()) {
                            tags.add(tagSnap.getValue(String.class));
                        }
                    }

                    if ((name != null && name.contains(keyword)) || tags.contains(keyword)) {
                        Map<String, Object> product = new HashMap<>();
                        for (DataSnapshot field : child.getChildren()) {
                            product.put(field.getKey(), field.getValue());
                        }
                        product.put("id", child.getKey());
                        result.add(product);
                    }
                }
                latch.countDown();
            }

            @Override
            public void onCancelled(DatabaseError error) {
                latch.countDown();
            }
        });

        try {
            latch.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        return result;
    }

    // 자동완성
    public List<String> getAutocompleteSuggestions(String keyword) {
        Set<String> suggestions = new HashSet<>();
        CountDownLatch latch = new CountDownLatch(1);

        db.child("products").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                for (DataSnapshot productSnapshot : snapshot.getChildren()) {
                    String name = productSnapshot.child("name").getValue(String.class);
                    if (name != null && name.toLowerCase().contains(keyword.toLowerCase())) {
                        suggestions.add(name);
                    }

                    for (DataSnapshot tagSnap : productSnapshot.child("tags").getChildren()) {
                        String tag = tagSnap.getValue(String.class);
                        if (tag != null && tag.toLowerCase().contains(keyword.toLowerCase())) {
                            suggestions.add(tag);
                        }
                    }
                }
                latch.countDown();
            }

            @Override
            public void onCancelled(DatabaseError error) {
                latch.countDown();
            }
        });

        try {
            latch.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        return new ArrayList<>(suggestions);
    }

    // ID로 조회
    public Map<String, Object> getProductById(String id) {
        Map<String, Object> result = new HashMap<>();
        CountDownLatch latch = new CountDownLatch(1);

        db.child("products").child(id).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    for (DataSnapshot field : snapshot.getChildren()) {
                        result.put(field.getKey(), field.getValue());
                    }
                    result.put("id", snapshot.getKey());
                }
                latch.countDown();
            }

            @Override
            public void onCancelled(DatabaseError error) {
                latch.countDown();
            }
        });

        try {
            latch.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        return result;
    }

    // JSON 업로드
    public void addProductsFromJson(String jsonFilePath) {
        ObjectMapper mapper = new ObjectMapper();
        try {
            List<Map<String, Object>> products = mapper.readValue(
                    new File(jsonFilePath),
                    new TypeReference<>() {}
            );
            DatabaseReference ref = FirebaseDatabase.getInstance().getReference("products");
            for (Map<String, Object> product : products) {
                ref.push().setValueAsync(product);
            }
            System.out.println("제품 업로드 완료");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Product 객체 저장
    public void saveProductToFirebase(Product product) {
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("products").push();
        Map<String, Object> data = new HashMap<>();
        data.put("name", product.getName());
        data.put("description", product.getDescription());
        data.put("price", product.getPrice());
        data.put("imageUrl", product.getImageUrl());
        data.put("tags", product.getTags() != null ? product.getTags() : List.of("일반"));
        ref.setValueAsync(data);
    }
    
    // 전체 상품 조회 (Product 객체 타입)
    public List<Product> getAllProductsObject() {
        List<Product> products = new ArrayList<>();
        CountDownLatch latch = new CountDownLatch(1);

        db.child("products").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                for (DataSnapshot child : snapshot.getChildren()) {
                    Product product = child.getValue(Product.class);
                    if (product != null) {
                        products.add(product);
                    }
                }
                latch.countDown();
            }

            @Override
            public void onCancelled(DatabaseError error) {
                latch.countDown();
            }
        });

        try {
            latch.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        return products;
    }


}
