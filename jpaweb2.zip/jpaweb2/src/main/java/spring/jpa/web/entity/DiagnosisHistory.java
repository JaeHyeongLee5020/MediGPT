package spring.jpa.web.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity
@Table(name = "diagnosis_history")
@Getter @Setter
@NoArgsConstructor
public class DiagnosisHistory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String userId; // userId로 변경

    private String symptom;

    @Column(length = 2000)
    private String diagnosis;

    @Column(length = 2000)
    private String medications;

    private LocalDateTime createdAt;

    @PrePersist
    public void prePersist() {
        this.createdAt = LocalDateTime.now();
    }
}
