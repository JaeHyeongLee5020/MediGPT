package spring.jpa.web.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import spring.jpa.web.entity.Post;
import spring.jpa.web.repository.PostRepository;

import java.net.URI;
import java.util.Optional;

@RestController
@RequestMapping("/api/posts")
@RequiredArgsConstructor
public class PostApiController {

    private final PostRepository postRepository;

    /** (POST) JSON으로 글 생성 */
    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Post> apiCreate(@RequestBody Post post) {
        Post saved = postRepository.save(post);
        return ResponseEntity
                .created(URI.create("/api/posts/" + saved.getId()))
                .body(saved);
    }

    /** (PUT) JSON으로 글 수정 */
    @PutMapping(path = "/{id}", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Post> apiUpdate(
            @PathVariable Long id,
            @RequestBody Post dto
    ) {
        Optional<Post> existing = postRepository.findById(id);
        if (existing.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        Post post = existing.get();
        post.setTitle(dto.getTitle());
        post.setContent(dto.getContent());
        post.setImageUrl(dto.getImageUrl());
        post.setViewCount(dto.getViewCount());
        Post updated = postRepository.save(post);
        return ResponseEntity.ok(updated);
    }

    /** (DELETE) 글 삭제 */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> apiDelete(@PathVariable Long id) {
        if (!postRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        postRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}