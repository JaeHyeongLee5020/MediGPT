package spring.jpa.web.config;

import com.google.cloud.storage.Storage;
import com.google.cloud.storage.StorageOptions;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

import java.time.Duration;

@Configuration
public class AppConfig {

    /**
     * RestTemplate 을 타임아웃 설정과 함께 빈으로 등록합니다.
     * 연결 타임아웃 5초, 읽기 타임아웃 5초 설정 예시
     */
    @Bean
    public RestTemplate restTemplate(RestTemplateBuilder builder) {
        return builder
                .setConnectTimeout(Duration.ofSeconds(5))
                .setReadTimeout(Duration.ofSeconds(5))
                .build();
    }

    /**
     * Google Cloud Storage 클라이언트를 빈으로 등록합니다.
     * 
     * 1) 운영/테스트 환경에서 권장되는 ADC(Application Default Credentials) 사용 방식:
     *    - GOOGLE_APPLICATION_CREDENTIALS 환경변수로 설정된 서비스 계정 JSON을 자동 로드합니다.
     */
    @Bean
    public Storage storage() {
        return StorageOptions.getDefaultInstance()
                             .getService();  // ADC 방식 :contentReference[oaicite:0]{index=0}
        
        // 2) 로컬 에뮬레이터나 인증 없이 테스트용으로만 사용하려면 아래를 대신 사용할 수 있습니다.
        // return StorageOptions.getUnauthenticatedInstance().getService();  // 무인증 방식 :contentReference[oaicite:1]{index=1}
    }
}