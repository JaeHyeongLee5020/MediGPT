package spring.jpa.web.service;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import org.springframework.stereotype.Service;
import spring.jpa.web.entity.User;

import java.util.HashMap;
import java.util.Map;

@Service
public class UserService {

    private final DatabaseReference db = FirebaseDatabase.getInstance().getReference();

    public void register(User user) {
        Map<String, Object> data = new HashMap<>();
        data.put("username", user.getUsername());
        data.put("password", user.getPassword());
        data.put("email", user.getEmail());
        data.put("age", user.getAge());
        data.put("phone", user.getPhone());
        data.put("name", user.getName());
        data.put("address", user.getAddress());

        db.child("users").child(user.getUsername()).setValueAsync(data);
    }
}
