package spring.jpa.web.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import spring.jpa.web.service.FirebaseUserService;

import com.google.firebase.database.*;
import jakarta.servlet.http.HttpSession;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.CountDownLatch;
import java.util.*;

@Controller
@RequiredArgsConstructor
public class MyInfoController {

    private final FirebaseUserService firebaseUserService;

    @GetMapping("/myInfo")
    public String showMyInfo(HttpSession session, Model model) {
        String username = (String) session.getAttribute("username");
        if (username == null) {
            return "redirect:/login";
        }

        session.setMaxInactiveInterval(1800); // 세션 유지시간 30분 설정

        Map<String, Object> userInfo = firebaseUserService.getUserInfo(username);
        model.addAttribute("user", userInfo);
        session.setAttribute("userInfo", userInfo); // 프로필 이미지 업로드용

        try {
            int maxInactiveInterval = session.getMaxInactiveInterval();
            long lastAccessedTime = session.getLastAccessedTime();
            long currentTime = System.currentTimeMillis();
            int remainingSeconds = (int) ((maxInactiveInterval * 1000L - (currentTime - lastAccessedTime)) / 1000);
            model.addAttribute("remainingSeconds", Math.max(remainingSeconds, 0));
        } catch (IllegalStateException e) {
            model.addAttribute("remainingSeconds", 0);
        }

        return "myInfo";
    }

    @PostMapping("/myInfo")
    public String updateMyInfo(@RequestParam Map<String, String> paramMap,
                               HttpSession session, Model model) {
        String username = (String) session.getAttribute("username");
        if (username == null) return "redirect:/login";

        Map<String, Object> current = firebaseUserService.getUserInfo(username);
        firebaseUserService.updateUserInfo(username, paramMap);

        String changedField = "";
        for (String key : paramMap.keySet()) {
            String oldVal = String.valueOf(current.get(key));
            String newVal = paramMap.get(key);
            if (!oldVal.equals(newVal)) {
                changedField = switch (key) {
                    case "name" -> "이름 정보가 수정되었습니다!";
                    case "email" -> "이메일 정보가 수정되었습니다!";
                    case "phone" -> "전화번호 정보가 수정되었습니다!";
                    case "age" -> "나이 정보가 수정되었습니다!";
                    case "address" -> "주소 정보가 수정되었습니다!";
                    default -> "정보가 수정되었습니다!";
                };
                break;
            }
        }

        session.setAttribute("updateMessage", changedField);
        return "redirect:/myInfo";
    }

    @PostMapping("/uploadProfileImage")
    public String uploadProfileImage(@RequestParam("profileImage") MultipartFile file,
                                     HttpSession session) {
        String username = (String) session.getAttribute("username");
        if (username == null || file.isEmpty()) return "redirect:/myInfo";

        Map<String, Object> userInfo = firebaseUserService.getUserInfo(username);
        String userId = String.valueOf(userInfo.get("id"));

        try {
            String uploadPath = new File("src/main/webapp/images/profile").getAbsolutePath();
            File dir = new File(uploadPath);
            if (!dir.exists()) dir.mkdirs();

            File dest = new File(uploadPath, userId + ".jpg");
            file.transferTo(dest);
        } catch (IOException e) {
            e.printStackTrace();
        }

        return "redirect:/myInfo";
    }

    @GetMapping("/changePassword")
    public String showChangePassword(HttpSession session) {
        if (session.getAttribute("username") == null) {
            return "redirect:/login";
        }
        return "changePassword";
    }

    @PostMapping("/changePassword")
    public String changePassword(@RequestParam("currentPassword") String currentPassword,
                                 @RequestParam("newPassword") String newPassword,
                                 HttpSession session,
                                 Model model) {
        String username = (String) session.getAttribute("username");
        if (username == null) {
            return "redirect:/login";
        }

        boolean changed = firebaseUserService.changePassword(username, currentPassword, newPassword);
        if (changed) {
            session.invalidate(); // 비밀번호 변경 후 로그아웃
            return "redirect:/login";
        } else {
            model.addAttribute("error", "현재 비밀번호가 일치하지 않습니다.");
            return "changePassword";
        }
    }

    @PostMapping("/deleteAccount")
    public String deleteAccount(HttpSession session) {
        String username = (String) session.getAttribute("username");
        if (username != null) {
            firebaseUserService.deleteUser(username);
            session.invalidate();
        }
        return "redirect:/login";
    }

    // 결제 내역 조회
    @GetMapping("/myInfo/payment-history")
    public String showPaymentHistory(HttpSession session, Model model) {
        String username = (String) session.getAttribute("username");
        if (username == null) return "redirect:/login";

        session.setMaxInactiveInterval(1800);

        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("paymentHistory").child(username);
        List<Map<String, Object>> paymentList = new ArrayList<>();
        CountDownLatch latch = new CountDownLatch(1);

        ref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                try {
                    for (DataSnapshot record : snapshot.getChildren()) {
                        Map<String, Object> data = new HashMap<>();
                        data.put("timestamp", record.getKey());
                        data.put("total", record.child("total").getValue());

                        DataSnapshot productsSnapshot = record.child("products");
                        List<Map<String, Object>> productList = new ArrayList<>();
                        for (DataSnapshot productEntry : productsSnapshot.getChildren()) {
                            Object value = productEntry.getValue();
                            if (value instanceof Map) {
                                productList.add((Map<String, Object>) value);
                            }
                        }

                        data.put("products", productList);
                        paymentList.add(data);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    latch.countDown();
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                latch.countDown();
            }
        });

        try {
            latch.await();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        model.addAttribute("paymentHistory", paymentList);
        return "paymentHistory";
    }
}
