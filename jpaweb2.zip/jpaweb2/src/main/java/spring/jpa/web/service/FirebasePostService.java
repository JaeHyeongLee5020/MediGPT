package spring.jpa.web.service;

import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.Map;

public interface FirebasePostService {
    List<Map<String, Object>> getAllPosts();
    Map<String, Object> getPostAndIncreaseView(String id);
    void createPost(Map<String, Object> postData);

    /** 이미지 파일을 Firebase Storage에 업로드하고 public URL을 반환 */
    String uploadImageAndGetUrl(MultipartFile file) throws IOException;
}