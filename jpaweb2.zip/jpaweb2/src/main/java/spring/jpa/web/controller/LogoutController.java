package spring.jpa.web.controller;

import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class LogoutController {

    @GetMapping("/logout")
    public String logout(HttpSession session, RedirectAttributes redirectAttributes) {
        session.invalidate(); // 세션 만료
        redirectAttributes.addFlashAttribute("logoutMsg", "로그아웃 되었습니다.");
        return "redirect:/login"; // 로그인 페이지로 리다이렉트
    }
}
