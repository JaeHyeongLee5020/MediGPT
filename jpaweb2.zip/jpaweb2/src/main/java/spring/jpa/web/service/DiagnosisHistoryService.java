package spring.jpa.web.service;

import com.google.firebase.database.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.CountDownLatch;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Service
@RequiredArgsConstructor
public class DiagnosisHistoryService {

    private final DatabaseReference db = FirebaseDatabase.getInstance().getReference();

    public void saveHistory(String userId, String symptom, String diagnosis, List<String> medications) {
        Map<String, Object> history = new HashMap<>();
        history.put("userId", userId);
        history.put("symptom", symptom);
        history.put("diagnosis", diagnosis);
        history.put("medications", medications);

        long timestamp = System.currentTimeMillis();
        history.put("timestamp", timestamp);

        String formattedTime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        history.put("createdAt", formattedTime);

        db.child("diagnosis_history").child(userId).child(String.valueOf(timestamp)).setValueAsync(history);
    }

    public List<Map<String, Object>> getUserHistory(String userId) {
        List<Map<String, Object>> historyList = new ArrayList<>();
        CountDownLatch latch = new CountDownLatch(1);

        db.child("diagnosis_history").child(userId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                for (DataSnapshot entry : snapshot.getChildren()) {
                    Map<String, Object> data = (Map<String, Object>) entry.getValue();
                    historyList.add(data);
                }
                latch.countDown();
            }

            @Override
            public void onCancelled(DatabaseError error) {
                latch.countDown();
            }
        });

        try {
            latch.await();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        historyList.sort((a, b) -> {
            Long t1 = a.get("timestamp") != null ? ((Number) a.get("timestamp")).longValue() : 0L;
            Long t2 = b.get("timestamp") != null ? ((Number) b.get("timestamp")).longValue() : 0L;
            return Long.compare(t2, t1);
        });

        return historyList;
    }

    public List<Map<String, Object>> getSymptomList(String userId) {
        List<Map<String, Object>> list = new ArrayList<>();
        CountDownLatch latch = new CountDownLatch(1);

        db.child("diagnosis_history").child(userId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                for (DataSnapshot entry : snapshot.getChildren()) {
                    Map<String, Object> item = new HashMap<>();
                    item.put("timestamp", entry.child("timestamp").getValue());
                    item.put("symptom", entry.child("symptom").getValue());
                    list.add(item);
                }
                latch.countDown();
            }

            @Override
            public void onCancelled(DatabaseError error) {
                latch.countDown();
            }
        });

        try {
            latch.await();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        list.sort((a, b) -> {
            Long t1 = a.get("timestamp") != null ? ((Number) a.get("timestamp")).longValue() : 0L;
            Long t2 = b.get("timestamp") != null ? ((Number) b.get("timestamp")).longValue() : 0L;
            return Long.compare(t2, t1);
        });

        return list;
    }

    public void deleteHistory(String userId, String timestamp) {
        db.child("diagnosis_history").child(userId).child(timestamp).removeValueAsync();
    }

    
    public Map<String, Object> getDiagnosisByTimestamp(String userId, String timestamp) {
        Map<String, Object> record = new HashMap<>();
        CountDownLatch latch = new CountDownLatch(1);

        db.child("diagnosis_history").child(userId).child(timestamp).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    record.putAll((Map<String, Object>) snapshot.getValue());
                }
                latch.countDown();
            }

            @Override
            public void onCancelled(DatabaseError error) {
                latch.countDown();
            }
        });

        try {
            latch.await();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        return record;
    }
    
}
