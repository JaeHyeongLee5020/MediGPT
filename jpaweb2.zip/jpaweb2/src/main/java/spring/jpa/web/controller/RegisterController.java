package spring.jpa.web.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import spring.jpa.web.service.FirebaseUserService;

import java.util.Map;

@Controller
public class RegisterController {

    @Autowired
    private FirebaseUserService firebaseUserService;

    @GetMapping("/register")
    public String showRegisterForm() {
        return "register"; // register.jsp
    }

    @PostMapping("/register")
    public String processRegister(@RequestParam("username") String username,
                                  @RequestParam("password") String password,
                                  @RequestParam("emailId") String emailId,
                                  @RequestParam("emailDomain") String emailDomain,
                                  @RequestParam("name") String name,
                                  @RequestParam("age") int age,
                                  @RequestParam("phone") String phone,
                                  @RequestParam("address") String address,
                                  @RequestParam(value = "agree", required = false) String agree,
                                  Model model) {

        if (agree == null) {
            model.addAttribute("error", "약관에 동의해야 회원가입이 가능합니다.");
            return "register";
        }

        String email = emailId + "@" + emailDomain;

        try {
            firebaseUserService.saveUser(username, password, email, age, phone, name, address);
            return "redirect:/register?result=success";
        } catch (Exception e) {
            return "redirect:/register?result=fail";
        }
    }


    @GetMapping("/check-username")
    @ResponseBody
    public Map<String, Boolean> checkUsername(@RequestParam("username") String username) {
        boolean available = !firebaseUserService.existsByUsername(username);
        return Map.of("available", available);
    }
}
