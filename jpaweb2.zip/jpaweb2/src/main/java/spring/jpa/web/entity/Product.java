package spring.jpa.web.entity;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class Product {
    private String name;
    private String description;
    private int price;
    private String imageUrl;
    private List<String> tags;
}
