package spring.jpa.web.controller;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import spring.jpa.web.service.GptService;
import spring.jpa.web.service.DiagnosisHistoryService;

@Controller
@RequiredArgsConstructor
public class MainController {

    private final GptService gptService;
    private final DiagnosisHistoryService diagnosisHistoryService;

    @GetMapping("/main")
    public String showMainPage(HttpSession session, Model model,
                               @RequestParam(value = "timestamp", required = false) String timestamp) {
        if (session == null || session.getAttribute("displayName") == null) {
            return "redirect:/login";
        }

        model.addAttribute("showWelcome", session.getAttribute("showWelcome"));
        session.removeAttribute("showWelcome");

        session.removeAttribute("symptom");
        session.removeAttribute("diagnosis");
        session.removeAttribute("recommendedMeds");

        String userId = (String) session.getAttribute("userId");
        if (userId != null) {
            List<Map<String, Object>> symptomList = diagnosisHistoryService.getSymptomList(userId);
            model.addAttribute("symptomList", symptomList);

            if (timestamp != null) {
                Map<String, Object> selectedRecord = diagnosisHistoryService.getDiagnosisByTimestamp(userId, timestamp);
                model.addAttribute("selectedRecord", selectedRecord);
                model.addAttribute("diagnosis", selectedRecord.get("diagnosis"));
                model.addAttribute("gptResponse", selectedRecord.get("medications"));

                // ✅ 처방전용 값 세션에 저장
                session.setAttribute("symptom", selectedRecord.get("symptom"));
                session.setAttribute("diagnosis", selectedRecord.get("diagnosis"));
                session.setAttribute("recommendedMeds", selectedRecord.get("medications"));
            }
        }

        setSessionRemainingTime(session, model);
        return "main";
    }

    @PostMapping("/gpt/ask")
    public String askGpt(@RequestParam("symptom") String symptom, HttpSession session, Model model) {
        if (session == null || session.getAttribute("displayName") == null) {
            return "redirect:/login";
        }

        List<String> medications = gptService.ask(symptom);
        String diagnosis = gptService.diagnose(symptom);

        session.setAttribute("recommendedMeds", medications);
        session.setAttribute("symptom", symptom);
        session.setAttribute("diagnosis", diagnosis);

        model.addAttribute("gptResponse", medications);
        model.addAttribute("diagnosis", diagnosis);
        model.addAttribute("showWelcome", false);

        String userId = (String) session.getAttribute("userId");
        if (userId != null) {
            diagnosisHistoryService.saveHistory(userId, symptom, diagnosis, medications);

            List<Map<String, Object>> symptomList = diagnosisHistoryService.getSymptomList(userId);
            model.addAttribute("symptomList", symptomList);
        }

        setSessionRemainingTime(session, model);
        return "main";
    }

    @GetMapping("/mypage/diagnosis_history")
    public String viewDiagnosisHistory(HttpSession session, Model model) {
        String userId = (String) session.getAttribute("userId");
        if (userId == null) {
            return "redirect:/login";
        }

        List<Map<String, Object>> historyList = diagnosisHistoryService.getUserHistory(userId);
        model.addAttribute("historyList", historyList);

        setSessionRemainingTime(session, model);
        return "mypage/diagnosis_history";
    }

    @GetMapping("/gpt/view-prescription")
    public String viewPrescription(HttpSession session, Model model,
                                   @RequestParam(value = "timestamp", required = false) String timestamp) {
        String userId = (String) session.getAttribute("userId");
        String username = (String) session.getAttribute("displayName");

        if (timestamp != null && userId != null) {
            Map<String, Object> selectedRecord = diagnosisHistoryService.getDiagnosisByTimestamp(userId, timestamp);
            if (selectedRecord != null) {
                model.addAttribute("qrData", "http://http://172.16.125.83:8080/gpt/view-prescription?timestamp=" + timestamp);
                model.addAttribute("username", username);
                model.addAttribute("symptom", selectedRecord.get("symptom"));
                model.addAttribute("diagnosis", selectedRecord.get("diagnosis"));
                model.addAttribute("meds", selectedRecord.get("medications"));
                model.addAttribute("date", LocalDate.now());
                return "prescription";
            }
        }

        // 세션 기반 fallback
        String symptom = (String) session.getAttribute("symptom");
        List<String> meds = (List<String>) session.getAttribute("recommendedMeds");
        String diagnosis = (String) session.getAttribute("diagnosis");

        if (username == null || symptom == null || meds == null) {
            return "redirect:/main";
        }

        model.addAttribute("qrData", "http://172.16.125.83:8080/gpt/view-prescription");
        model.addAttribute("username", username);
        model.addAttribute("symptom", symptom);
        model.addAttribute("diagnosis", diagnosis);
        model.addAttribute("meds", meds);
        model.addAttribute("date", LocalDate.now());

        return "prescription";
    }

    @GetMapping("/extend-session")
    @ResponseBody
    public String extendSession(HttpSession session) {
        if (session != null) {
            session.setMaxInactiveInterval(1800);
        }
        return "OK";
    }

    @PostMapping("/history/delete")
    @ResponseBody
    public String deleteHistory(@RequestParam("timestamp") String timestamp, HttpSession session) {
        String userId = (String) session.getAttribute("userId");
        if (userId != null && timestamp != null) {
            diagnosisHistoryService.deleteHistory(userId, timestamp);
            return "ok";
        }
        return "fail";
    }

    private void setSessionRemainingTime(HttpSession session, Model model) {
        try {
            int maxInactiveInterval = session.getMaxInactiveInterval();
            long lastAccessedTime = session.getLastAccessedTime();
            long currentTime = System.currentTimeMillis();
            int remainingSeconds = (int) ((maxInactiveInterval * 1000L - (currentTime - lastAccessedTime)) / 1000);
            model.addAttribute("remainingSeconds", Math.max(remainingSeconds, 0));
        } catch (IllegalStateException e) {
            model.addAttribute("remainingSeconds", 0);
        }
    }
}
