package spring.jpa.web.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import spring.jpa.web.entity.User;

public interface UserRepository extends JpaRepository<User, String> {
}
