package spring.jpa.web.service;

import com.google.firebase.database.*;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CountDownLatch;

@Service
public class FirebaseUserService {

    private final DatabaseReference db = FirebaseDatabase.getInstance().getReference();

    // 회원 저장
    public void saveUser(String username, String password, String email, int age, String phone, String name, String address) {
        Map<String, Object> userMap = new HashMap<>();
        userMap.put("username", username);
        userMap.put("password", password);
        userMap.put("email", email);
        userMap.put("age", age);
        userMap.put("phone", phone);
        userMap.put("name", name);
        userMap.put("address", address);
        db.child("users").child(username).setValueAsync(userMap);
    }

    // 아이디 중복 확인
    public boolean existsByUsername(String username) {
        try {
            DatabaseReference userRef = db.child("users").child(username);
            final boolean[] exists = {false};
            CountDownLatch latch = new CountDownLatch(1);

            userRef.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot snapshot) {
                    exists[0] = snapshot.exists();
                    latch.countDown();
                }

                @Override
                public void onCancelled(DatabaseError error) {
                    latch.countDown();
                }
            });

            latch.await();
            return exists[0];
        } catch (InterruptedException e) {
            e.printStackTrace();
            return true;
        }
    }

    // 로그인 인증
    public boolean authenticate(String username, String password) {
        try {
            DatabaseReference userRef = db.child("users").child(username);
            final boolean[] result = {false};
            CountDownLatch latch = new CountDownLatch(1);

            userRef.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot snapshot) {
                    if (snapshot.exists()) {
                        String dbPassword = snapshot.child("password").getValue(String.class);
                        if (password.equals(dbPassword)) {
                            result[0] = true;
                        }
                    }
                    latch.countDown();
                }

                @Override
                public void onCancelled(DatabaseError error) {
                    latch.countDown();
                }
            });

            latch.await();
            return result[0];
        } catch (InterruptedException e) {
            e.printStackTrace();
            return false;
        }
    }

    // 이름 조회
    public String getNameByUsername(String username) {
        try {
            DatabaseReference userRef = db.child("users").child(username);
            final String[] result = {null};
            CountDownLatch latch = new CountDownLatch(1);

            userRef.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot snapshot) {
                    if (snapshot.exists()) {
                        result[0] = snapshot.child("name").getValue(String.class);
                    }
                    latch.countDown();
                }

                @Override
                public void onCancelled(DatabaseError error) {
                    latch.countDown();
                }
            });

            latch.await();
            return result[0];
        } catch (InterruptedException e) {
            e.printStackTrace();
            return null;
        }
    }

    // 사용자 정보 조회
    public Map<String, Object> getUserInfo(String username) {
        Map<String, Object> userInfo = new HashMap<>();
        try {
            DatabaseReference userRef = db.child("users").child(username);
            CountDownLatch latch = new CountDownLatch(1);

            userRef.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot snapshot) {
                    if (snapshot.exists()) {
                        for (DataSnapshot child : snapshot.getChildren()) {
                            userInfo.put(child.getKey(), child.getValue());
                        }
                    }
                    latch.countDown();
                }

                @Override
                public void onCancelled(DatabaseError error) {
                    latch.countDown();
                }
            });

            latch.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return userInfo;
    }

    // 사용자 정보 수정
    public void updateUserInfo(String username, Map<String, String> updates) {
        db.child("users").child(username).updateChildrenAsync(new HashMap<>(updates));
    }

    // 회원 탈퇴
    public void deleteUser(String username) {
        db.child("users").child(username).removeValueAsync();
    }

    // 비밀번호 변경
    public boolean changePassword(String username, String currentPassword, String newPassword) {
        try {
            DatabaseReference userRef = db.child("users").child(username);
            final boolean[] result = {false};
            CountDownLatch latch = new CountDownLatch(1);

            userRef.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot snapshot) {
                    if (snapshot.exists()) {
                        String dbPassword = snapshot.child("password").getValue(String.class);
                        if (dbPassword != null && dbPassword.equals(currentPassword)) {
                            userRef.child("password").setValue(newPassword, (error, ref) -> {
                                result[0] = (error == null);
                                latch.countDown();
                            });
                        } else {
                            latch.countDown();
                        }
                    } else {
                        latch.countDown();
                    }
                }

                @Override
                public void onCancelled(DatabaseError error) {
                    latch.countDown();
                }
            });

            latch.await();
            return result[0];

        } catch (InterruptedException e) {
            e.printStackTrace();
            return false;
        }
    }
}
