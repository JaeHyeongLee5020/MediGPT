package spring.jpa.web.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.*;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class User {

    @Id
    private String username;

    private String password;
    private String email;
    private int age;
    private String phone;
    private String name;      // 이름
    private String address;   // 주소
}
